FIRES = {}

def append_fire(fire)
  FIRES[fire] = true
end